# Declarations

## Assistance and responsibility

AI assistance. Dou Bao supported literature and reference checking and translation. Trae Code CN supported code checking. Codex supported manuscript revision, analysis scripts, figure preparation, source adaptation and the post-review qualitative coding reported in Section S28. That coding was unblinded and was not an independent teacher assessment. The source dataset includes model-assisted transcripts or screen descriptions. The author confirmed that both teachers personally supplied their ratings without AI assistance. Experimental tutoring outputs were generated with Qwen3 and Llama3.1 as reported in the Methods. The author is responsible for the study design, analyses, verification, interpretation, references and final manuscript. No model training was performed.

## Evaluation records

Teacher judgments and post-review diagnostic codes are separate data products. The diagnostic coding was conducted with the ratings visible and was not an additional teacher evaluation. This documentation update changes no label, diagnostic code or numerical result.

## Ethics and access

Ethics review. No institutional ethics review or waiver was obtained for the secondary analysis and teacher evaluations reported in this study.

The author confirmed permission to share de-identified rating labels from both teachers. Raw dialogue, teacher explanations, handwriting and private identity mappings are excluded. The manuscript availability statement and LICENSE_SCOPE.md specify the public scope.
