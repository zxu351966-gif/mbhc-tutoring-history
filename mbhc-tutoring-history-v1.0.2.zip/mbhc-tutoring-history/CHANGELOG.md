# Changes

## 1.0.2

Consolidated assistance and responsibility statements in DECLARATIONS.md and
updated the README and data dictionary to distinguish teacher judgments from
post-review diagnostic coding. No changes to data, prompts, code, numerical
targets or licences.

## 1.0.1

Revised README and data dictionary for clarity. No changes to research data,
system prompts, analysis code, numerical targets or licences.

## 1.0.0

Initial release of the de-identified results, prompts and analysis code.
