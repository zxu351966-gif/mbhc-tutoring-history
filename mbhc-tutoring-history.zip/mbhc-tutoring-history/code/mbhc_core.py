"""Readable refactoring of the archived exact-budget history selector.

The caller supplies record costs. This module does not call a tokenizer or model.
JSON serialization, prompt spacing, ranking and tie handling follow the archived
implementation. This extract does not implement the full study pipeline.
"""

import hashlib
import json
import math
import re
from collections import Counter

HISTORY_CAP = 512
STOP = set(
    "the and that this with what when have from your just like into here there then "
    "first would should could which why how for are you was were can not they she "
    "his her said but all now well yeah yes okay really going got about want know "
    "does doing mean more same get did one use let need think will how our out some "
    "also back going has been good very right because going make goes tell".split()
)
WORD = re.compile(r"[a-z0-9]+")


def digest(text):
    """Identify the exact UTF-8 record serialization used by the cost table."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def line(entry):
    # Keep default JSON spacing and insertion order: changing either changes the cost key.
    return json.dumps(entry, ensure_ascii=False) + "\n"


def body(cid, history, anchor):
    """Place selected history before the shared current state."""
    return (
        "case_id: "
        + cid
        + "\nprior_history:\n"
        + "".join(line(record) for record in history)
        + "shared_current_state:\n"
        + "".join(line(record) for record in anchor)
    )


def render(system, user):
    """Render the archived Qwen3 request, including its exact whitespace."""
    return (
        f"<|im_start|>system\n{system}<|im_end|>\n"
        f"<|im_start|>user\n{user} /no_think<|im_end|>\n"
        "<|im_start|>assistant\n<think>\n\n</think>\n\n"
    )


def words(text):
    """Return distinct non-stopword terms; retain numbers of any length."""
    return {
        word
        for word in WORD.findall(text.lower())
        if word not in STOP and (len(word) > 2 or word.isdigit())
    }


def recent_states(past, cost):
    """Save each attainable cumulative cost from a newest-first pass."""
    selected, states, used = [], {}, 0
    for record in reversed(past):
        record_cost = cost[digest(line(record))]
        # A record that does not fit is skipped; older records may still fit.
        if used + record_cost <= HISTORY_CAP:
            selected.append(record)
            used += record_cost
            states[used] = list(selected)
    return states


def scored_records(past, anchor, cost):
    """Score lexical overlap with the current state, weighted by term rarity."""
    query = words(" ".join(record["text"] for record in anchor))
    documents = [words(record["text"]) for record in past]
    frequencies = Counter(word for document in documents for word in document)
    ranked = []
    for index, record in enumerate(past):
        overlap = query & documents[index]
        # Preserve the original set iteration and floating-point summation order.
        score = sum(
            1 + math.log((1 + len(past)) / (1 + frequencies[word])) for word in overlap
        ) / math.sqrt(max(1, len(documents[index])))
        record_cost = cost[digest(line(record))]
        if score > 0 and 0 < record_cost <= HISTORY_CAP:
            ranked.append((record, record_cost, score))
    return ranked


def best_subsets(ranked):
    """Find the highest-scoring whole-record subset at each exact cost."""
    best = [None] * (HISTORY_CAP + 1)
    best[0] = (0.0, ())
    for index, (_, record_cost, score) in enumerate(ranked):
        # Descending costs prevent the same record from being chosen twice.
        for target in range(HISTORY_CAP, record_cost - 1, -1):
            previous = best[target - record_cost]
            if previous is None:
                continue
            total = previous[0] + score
            # Strict > keeps the earlier subset on a score tie.
            if best[target] is None or total > best[target][0]:
                best[target] = (total, previous[1] + (index,))
    return best


def matched_history(past, anchor, cost):
    """Return (recent, relevant, matched_cost, status) without changing records.

    Records need ``context_id`` and ``text``. Cost keys are ``digest(line(record))``;
    values are caller-supplied integer record costs. The current-state records are
    used as the query and are not charged to this history-only allowance.
    """
    # 1. Collect the costs reached by the archived recent-history rule.
    states = recent_states(past, cost)

    # 2. Optimize relevant whole-record subsets at each possible cost.
    ranked = scored_records(past, anchor, cost)
    best = best_subsets(ranked)

    # 3. Use the largest positive cost attainable by both selectors.
    shared_costs = [size for size in states if size > 0 and best[size] is not None]
    if not shared_costs:
        return [], [], 0, "NO_POSITIVE_WHOLE_ENTRY_MATCH"
    target = max(shared_costs)
    relevant = [ranked[index][0] for index in best[target][1]]
    recent = states[target]

    # 4. Restore chronological record order before constructing either input.
    def context_order(record):
        return int(record["context_id"][1:])

    recent.sort(key=context_order)
    relevant.sort(key=context_order)
    recent_cost = sum(cost[digest(line(record))] for record in recent)
    relevant_cost = sum(cost[digest(line(record))] for record in relevant)
    if not recent_cost == target == relevant_cost:
        raise ValueError("Selected histories do not have the matched record cost")
    if len({record["context_id"] for record in relevant}) != len(relevant):
        raise ValueError("Relevant history contains duplicate context IDs")
    return recent, relevant, target, "MATCH_FOUND"
