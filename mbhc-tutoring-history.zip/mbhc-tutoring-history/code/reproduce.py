"""Recalculate the reported summaries from the released labels and fixed codes.

Run from any directory with ``python code/reproduce.py --out replay``.
Add ``--bootstrap`` to recalculate the archived percentile intervals with NumPy.
"""

import argparse
import csv
import json
import math
import statistics
from collections import Counter
from pathlib import Path

from verify_manifest import verify_manifest

ROOT = Path(__file__).resolve().parents[1]
TEACHERS = ("A", "B")
SEEDS = ("42", "43", "44")
LABELS = ("yes", "no", "uncertain")
HISTORY_CONDITIONS = ("recent", "relevant")
DIMENSIONS = ("ACM", "NMA", "DA", "EIS", "NAMA", "IAP")
BOOTSTRAP_SEED = 20261029
BOOTSTRAP_DRAWS = 20_000


def require(condition, message):
    """Stop on an invalid input or changed result, including under python -O."""
    if not condition:
        raise ValueError(message)


def read_json(relative_path):
    return json.loads((ROOT / relative_path).read_text(encoding="utf8"))


def read_rows(filename):
    with (ROOT / "data" / filename).open(encoding="utf8", newline="") as handle:
        return list(csv.DictReader(handle))


def select(records, **fields):
    """Filter without changing the order of the released rows."""
    return [row for row in records if all(row[key] == value for key, value in fields.items())]


def unit_ids(records):
    # First-seen order is part of the archived bootstrap calculation.
    return list(dict.fromkeys(row["unit"] for row in records))


def label_counts(records, field="NMA"):
    return {label: sum(row[field] == label for row in records) for label in LABELS}


def check_equal(actual, expected, location="result"):
    """Compare nested results using the original numerical tolerance."""
    if isinstance(actual, dict):
        require(actual.keys() == expected.keys(), f"{location}: different keys")
        for key in actual:
            check_equal(actual[key], expected[key], f"{location}.{key}")
    elif isinstance(actual, list):
        require(len(actual) == len(expected), f"{location}: different list lengths")
        for index, (value, reference) in enumerate(zip(actual, expected)):
            check_equal(value, reference, f"{location}[{index}]")
    elif isinstance(actual, (int, float)):
        require(
            math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-10),
            f"{location}: {actual!r} != {expected!r}",
        )
    else:
        require(actual == expected, f"{location}: {actual!r} != {expected!r}")


def agreement(records, field="NMA"):
    """Count each output once per teacher, then calculate agreement and kappa."""
    by_teacher = {
        teacher: {row["output"]: row[field] for row in select(records, teacher=teacher)}
        for teacher in TEACHERS
    }
    ratings_a, ratings_b = by_teacher["A"], by_teacher["B"]
    require(ratings_a.keys() == ratings_b.keys(), "Teachers have different output IDs")
    total = len(ratings_a)
    pairs = Counter((ratings_a[key], ratings_b[key]) for key in ratings_a)
    marginal_a, marginal_b = Counter(ratings_a.values()), Counter(ratings_b.values())
    same = sum(pairs[label, label] for label in LABELS)
    chance = sum(marginal_a[label] * marginal_b[label] for label in LABELS) / total**2
    return dict(
        n=total,
        same=same,
        percent=100 * same / total,
        kappa=(same / total - chance) / (1 - chance),
        matrix=[dict(A=a, B=b, n=pairs[a, b]) for a in LABELS for b in LABELS],
    )


def load_inputs():
    """Load the seven analysis tables and check their released row counts."""
    files = {
        "actual": ("tutor_actual264.csv", 264),
        "common": ("tutor_common528.csv", 528),
        "external": ("eedi_original420.csv", 420),
        "slots": ("eedi_original_slots456.csv", 456),
        "external_pairs": ("eedi_original_pairs144.csv", 144),
        "followup": ("followup_judgments1512.csv", 1512),
        "followup_pairs": ("followup_pairs720.csv", 720),
    }
    tables = {}
    for name, (filename, expected_rows) in files.items():
        tables[name] = read_rows(filename)
        require(len(tables[name]) == expected_rows, f"{filename}: unexpected row count")
    return tables


def actual_input_summaries(actual):
    """Tables 4–6: retain the actual-input rating round as its own analysis."""
    condition_counts = [
        dict(
            teacher=teacher,
            condition=condition,
            **label_counts(select(actual, teacher=teacher, condition=condition)),
        )
        for teacher in TEACHERS
        for condition in HISTORY_CONDITIONS
    ]
    check_equal(
        [(row["yes"], row["no"], row["uncertain"]) for row in condition_counts],
        [(35, 9, 0), (32, 12, 0), (33, 8, 3), (36, 7, 1)],
        "table4_actual",
    )
    local_counts = [
        dict(
            teacher=teacher, **label_counts(select(actual, teacher=teacher, condition="local"))
        )
        for teacher in TEACHERS
    ]
    primary = [row for row in actual if row["condition"] in HISTORY_CONDITIONS]
    dimension_agreement = {dimension: agreement(primary, dimension) for dimension in DIMENSIONS}
    check_equal(
        [dimension_agreement[d]["same"] for d in DIMENSIONS],
        [70, 79, 68, 53, 83, 73],
        "table5_agreement",
    )
    return {
        "table4_actual": condition_counts,
        "table6_local": local_counts,
        "table5_agreement": dimension_agreement,
        "figure4": figure4_values(actual, primary),
    }


def figure4_values(actual, primary):
    """Calculate each student's contrast and the leave-one-student-out means."""
    points = []
    for unit in unit_ids(actual):
        point = dict(unit=unit)
        for teacher in TEACHERS:
            records = select(primary, teacher=teacher, unit=unit)
            require(len(records) == 8, f"Figure 4: expected eight rows for {teacher}/{unit}")
            recent_yes = sum(
                row["NMA"] == "yes" and row["condition"] == "recent" for row in records
            )
            relevant_yes = sum(
                row["NMA"] == "yes" and row["condition"] == "relevant" for row in records
            )
            # Four prompt variants per condition: one yes judgment is 25 percentage points.
            point[teacher] = 25 * (relevant_yes - recent_yes)
        points.append(point)
    reference = {row["unit"]: row for row in read_rows("figure4_points.csv")}
    for point in points:
        for teacher in TEACHERS:
            check_equal(point[teacher], float(reference[point["unit"]][teacher]), "figure4")
    leave_one_out = [
        dict(
            unit=point["unit"],
            **{
                teacher: statistics.mean(
                    other[teacher] for other in points if other["unit"] != point["unit"]
                )
                for teacher in TEACHERS
            },
        )
        for point in points
    ]
    return dict(points=points, leave_one_out=leave_one_out)


def common_reference_summaries(common):
    """Table 2: compare histories within each teacher and generation seed."""
    summaries = []
    for teacher in TEACHERS:
        for seed in SEEDS:
            counts = {
                condition: label_counts(
                    select(common, teacher=teacher, seed=seed, condition=condition)
                )
                for condition in HISTORY_CONDITIONS
            }
            # The 44 judgments are 11 students × four prompts, not 44 independent students.
            difference = 100 * (counts["relevant"]["yes"] - counts["recent"]["yes"]) / 44
            summaries.append(
                dict(teacher=teacher, seed=int(seed), counts=counts, difference_pp=difference)
            )
    check_equal(
        [row["counts"]["recent"]["yes"] for row in summaries],
        [25, 14, 14, 29, 32, 28],
        "table2_recent",
    )
    check_equal(
        [row["counts"]["relevant"]["yes"] for row in summaries],
        [29, 18, 18, 31, 29, 31],
        "table2_relevant",
    )
    return {
        "table2_common": summaries,
        "common_agreement": {seed: agreement(select(common, seed=seed)) for seed in SEEDS},
    }


def external_summaries(external, slots, pairs):
    """Table 3: use condition slots for counts and unique outputs for agreement."""
    eligible = {row["unit"] for row in pairs}
    counts = [
        dict(
            teacher=teacher,
            seed=int(seed),
            condition=condition,
            **label_counts(
                [
                    row
                    for row in select(slots, teacher=teacher, seed=seed, condition=condition)
                    if row["unit"] in eligible
                ]
            ),
        )
        for teacher in TEACHERS
        for seed in SEEDS
        for condition in (*HISTORY_CONDITIONS, "full_visible_prefix")
    ]
    output_agreement = agreement(external)
    check_equal(output_agreement["same"], 177, "external_agreement")
    distinct = []
    for teacher in TEACHERS:
        records = select(pairs, teacher=teacher, same_input="0")
        # This subset has 18 conversations × three seeds for each teacher.
        require(len(records) == 54, "Distinct-input subset: expected 54 pairs per teacher")
        distinct.append(
            dict(
                teacher=teacher,
                n=54,
                recent_yes=sum(row["recent"] == "yes" for row in records),
                relevant_yes=sum(row["relevant"] == "yes" for row in records),
            )
        )
    return {
        "table3_external": counts,
        "external_agreement": output_agreement,
        "external_distinct18": distinct,
    }


def condition_alias(model, rule, cap, condition):
    if model == "Qwen3" and condition in HISTORY_CONDITIONS:
        return f"{rule}_{cap}_{condition}"
    return condition


def followup_effects_and_counts(judgments, pairs):
    """Average the three seed differences within each conversation and setting."""
    effects, conditions, seed_counts = {}, [], []
    for teacher in TEACHERS:
        teacher_pairs = select(pairs, teacher=teacher)
        settings = dict.fromkeys(row["setting"] for row in teacher_pairs)
        for setting in settings:
            records = select(teacher_pairs, setting=setting)
            metadata = records[0]
            units = unit_ids(records)
            require(
                len(units) == 24 and len(records) == 72, f"{setting}: expected 24 × three pairs"
            )
            effects[teacher, setting] = {
                unit: sum(
                    int(row["relevant"] == "yes") - int(row["recent"] == "yes")
                    for row in records
                    if row["unit"] == unit
                )
                / 3
                for unit in units
            }
            # Identical inputs remain in the analysis and must reuse the same output and label.
            for row in records:
                require(row["same_input"] in ("0", "1"), "Invalid same_input flag")
                if row["same_input"] == "1":
                    require(
                        row["recent_output"] == row["relevant_output"]
                        and row["recent"] == row["relevant"],
                        "Same-input pair is inconsistent",
                    )
            model, rule, cap = metadata["model"], metadata["rule"], int(metadata["cap"])
            full_prefix = (
                "full_visible_prefix_reference" if model == "Qwen3" else "full_visible_prefix"
            )
            for condition in (*HISTORY_CONDITIONS, full_prefix):
                alias = condition_alias(model, rule, cap, condition)
                selected = [
                    row
                    for row in select(judgments, teacher=teacher, model=model)
                    if row["unit"] in units and alias in json.loads(row["condition_aliases"])
                ]
                counts = label_counts(selected)
                require(
                    len(selected) == 72, f"{setting}/{condition}: expected 72 condition cells"
                )
                conditions.append(
                    dict(
                        reviewer=teacher,
                        model=model,
                        cap=cap,
                        rule=rule,
                        cohort="common_qwen24" if model == "Qwen3" else "model_primary24",
                        condition=condition,
                        conversations=24,
                        repeated_condition_cells=72,
                        unique_outputs=len({row["output"] for row in selected}),
                        **counts,
                        yes_percent=100 * counts["yes"] / 72,
                    )
                )
            for seed in SEEDS:
                selected = select(records, seed=seed)
                gain = sum(
                    row["recent"] != "yes" and row["relevant"] == "yes" for row in selected
                )
                loss = sum(
                    row["recent"] == "yes" and row["relevant"] != "yes" for row in selected
                )
                seed_counts.append(
                    dict(
                        reviewer=teacher,
                        setting=setting,
                        seed=int(seed),
                        conversations=24,
                        recent_yes=sum(row["recent"] == "yes" for row in selected),
                        relevant_yes=sum(row["relevant"] == "yes" for row in selected),
                        gain=gain,
                        loss=loss,
                        difference_pp=100 * (gain - loss) / 24,
                        same_input_pairs=sum(row["same_input"] == "1" for row in selected),
                    )
                )
    check_equal(
        conditions, read_json("expected/followup_condition_counts.json"), "followup_conditions"
    )
    check_equal(
        seed_counts, read_json("expected/followup_seed_contrasts.json"), "followup_seeds"
    )
    return effects, conditions, seed_counts


def coverage_summaries(judgments):
    """Keep the 28-conversation coverage cohort separate from the matched cohort."""
    coverage = []
    for expected in read_json("expected/followup_coverage28.json"):
        selected = [
            row
            for row in select(judgments, teacher=expected["reviewer"], model=expected["model"])
            if expected["condition"] in json.loads(row["condition_aliases"])
        ]
        require(
            len(selected) == 84 and len(unit_ids(selected)) == 28,
            "Coverage: expected 28 × three rows",
        )
        counts = label_counts(selected)
        for label, value in counts.items():
            check_equal(value, expected[label], f"coverage.{label}")
        check_equal(100 * counts["yes"] / 84, expected["yes_percent"], "coverage.yes_percent")
        coverage.append(
            dict(
                reviewer=expected["reviewer"],
                model=expected["model"],
                condition=expected["condition"],
                **counts,
            )
        )
    return coverage


def contrast_values(specification, effects):
    """Resolve the archived contrast definition into ordered conversation effects."""
    teacher, name = specification["reviewer"], specification["contrast"]
    if specification["cohort"] == "within_model24":
        setting = f"{specification['model']}_{specification['rule']}_{specification['cap']}"
        return list(effects[teacher, setting].values())
    if name.startswith("Qwen3 ceiling minus exact"):
        cap = int(name.split("at")[1])
        return [
            value - effects[teacher, f"Qwen3_exact_{cap}"][unit]
            for unit, value in effects[teacher, f"Qwen3_ceiling_{cap}"].items()
        ]
    if name.startswith("Qwen3 256 minus512"):
        rule = name.split()[-1]
        return [
            value - effects[teacher, f"Qwen3_{rule}_512"][unit]
            for unit, value in effects[teacher, f"Qwen3_{rule}_256"].items()
        ]

    # Cross-model comparisons use the 22 shared conversations, in Qwen's source order.
    qwen = effects[teacher, "Qwen3_exact_512"]
    llama = effects[teacher, "Llama3.1_exact_512"]
    shared_units = [unit for unit in qwen if unit in llama]
    require(len(shared_units) == 22, "Cross-model contrast: expected 22 shared conversations")
    if name.startswith("Llama minus"):
        return [llama[unit] - qwen[unit] for unit in shared_units]
    model_effects = llama if name.startswith("Llama3.1") else qwen
    return [model_effects[unit] for unit in shared_units]


def bootstrap_interval(values):
    """Resample conversations, preserving the archived seed and draw order."""
    import numpy as np

    array = np.asarray(values)
    # The original analysis restarted this seed for each contrast, not once per run.
    generator = np.random.default_rng(BOOTSTRAP_SEED)
    indices = generator.integers(0, len(array), size=(BOOTSTRAP_DRAWS, len(array)))
    means = array[indices].mean(axis=1)
    lower, upper = np.quantile(means, [0.025, 0.975])
    return dict(
        bootstrap95_lower_pp=100 * float(lower), bootstrap95_upper_pp=100 * float(upper)
    )


def followup_contrasts(effects, bootstrap):
    contrasts = []
    # Expected files provide the fixed comparison roster; values are recomputed from labels.
    for expected in read_json("expected/followup_contrasts.json"):
        values = contrast_values(expected, effects)
        computed = dict(
            conversations=len(values),
            difference_pp=100 * statistics.mean(values),
            conversation_min_pp=100 * min(values),
            conversation_max_pp=100 * max(values),
            positive_conversations=sum(value > 0 for value in values),
            zero_conversations=sum(value == 0 for value in values),
            negative_conversations=sum(value < 0 for value in values),
        )
        if bootstrap:
            computed.update(bootstrap_interval(values))
        for field, value in computed.items():
            check_equal(value, expected[field], f"{expected['contrast']}.{field}")
        contrasts.append(
            dict(teacher=expected["reviewer"], contrast=expected["contrast"], **computed)
        )
    return contrasts


def followup_summaries(judgments, pairs, bootstrap):
    effects, conditions, seeds = followup_effects_and_counts(judgments, pairs)
    output_agreement = agreement(judgments)
    check_equal(output_agreement["same"], 532, "followup_agreement.same")
    check_equal(
        output_agreement["kappa"],
        read_json("expected/followup_agreement.json")["kappa"],
        "followup_agreement.kappa",
    )
    return {
        "coverage28": coverage_summaries(judgments),
        "followup_contrasts": followup_contrasts(effects, bootstrap),
        "followup_conditions": conditions,
        "followup_seeds": seeds,
        "followup_agreement": output_agreement,
    }


def diagnostic_summaries():
    """Count retained diagnostic codes; categories can overlap within one row."""
    results = {}
    for name in ("attribution88", "eis35"):
        counts = Counter(
            code
            for row in read_rows(f"diagnostic_{name}.csv")
            for code in json.loads(row["code_ids"])
        )
        results[f"diagnostic_{name}"] = dict(counts)
    expected = read_json("expected/diagnostic_counts.json")
    check_equal(
        results["diagnostic_attribution88"],
        expected["attribution_counts"],
        "diagnostic_attribution88",
    )
    check_equal(results["diagnostic_eis35"], expected["eis_reason_codes"], "diagnostic_eis35")
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--out", type=Path, required=True, help="New directory for results.json"
    )
    parser.add_argument(
        "--bootstrap",
        action="store_true",
        help="Recalculate 20,000-draw intervals (requires NumPy)",
    )
    args = parser.parse_args()
    if args.out.exists():
        parser.error(f"Output directory already exists: {args.out}")

    # 1. Check release integrity before reading analysis inputs.
    verify_manifest(ROOT)
    tables = load_inputs()

    # 2. Calculate each rating round separately, keeping the archived result keys.
    results = actual_input_summaries(tables["actual"])
    results.update(common_reference_summaries(tables["common"]))
    results.update(
        external_summaries(tables["external"], tables["slots"], tables["external_pairs"])
    )
    results.update(
        followup_summaries(tables["followup"], tables["followup_pairs"], args.bootstrap)
    )
    results.update(diagnostic_summaries())

    # 3. Write only after all reference checks pass. Existing outputs are never overwritten.
    results["scope"] = (
        "Numerical replay of retained judgments and fixed codes, not independent human validation or regeneration"
    )
    results["bootstrap_recomputed"] = args.bootstrap
    args.out.mkdir()
    (args.out / "results.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2), encoding="utf8"
    )
    print(
        "PASS: Tables 2-7, Figure 4, external subset, all follow-up point contrasts, "
        "agreement and diagnostic counts" + ("; bootstrap intervals" if args.bootstrap else "")
    )


if __name__ == "__main__":
    main()
