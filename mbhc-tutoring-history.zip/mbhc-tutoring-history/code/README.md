# Reading the code

Start with `reproduce.py:main`. It checks the release, loads the tables, runs each
analysis and writes one `results.json`. Analysis functions follow the same order
in the file. They return dictionaries; only `main` writes the output file.

## Which script should I run?

| Script | Purpose | Dependencies |
| --- | --- | --- |
| `verify_manifest.py` | Check file hashes and report missing or unlisted files | Python standard library |
| `reproduce.py` | Recalculate counts, agreement, contrasts and Figure 4 values | Standard library; NumPy for `--bootstrap` |
| `test_synthetic.py` | Test the selector with small invented examples | Standard library |
| `mbhc_core.py` | Provide the exact-budget selector and archived request formatting | Standard library; imported by the tests |

## Analysis map

| Function in `reproduce.py` | Input | Result |
| --- | --- | --- |
| `actual_input_summaries` | `tutor_actual264.csv` | Tables 4–6 and Figure 4 |
| `common_reference_summaries` | `tutor_common528.csv` | Table 2 and agreement by seed |
| `external_summaries` | The three `eedi_original*` analysis files | Table 3, output agreement and the distinct-input subset |
| `followup_effects_and_counts` | `followup_judgments1512.csv`, `followup_pairs720.csv` | Within-conversation effects, condition counts and seed summaries |
| `coverage_summaries` | Follow-up judgments | The separate 28-conversation coverage analysis |
| `followup_contrasts` | Conversation effects | All 24 archived contrasts, with optional bootstrap intervals |
| `diagnostic_summaries` | `diagnostic_attribution88.csv`, `diagnostic_eis35.csv` | Counts of retained diagnostic codes |

The expected JSON files supply reference values. The contrast and coverage files
also define the fixed comparisons to calculate. Values are recomputed from the
released labels; expected values are then used to check them. Table numbers refer
to the manuscript accompanying this dataset, not to an execution order.

## Counting and resampling

- **Teachers and rounds stay separate.** Agreement pairs teachers by output ID.
- **Condition cells differ from unique outputs.** One output may serve several
  conditions. `condition_aliases` records that reuse; it does not create new ratings.
- **Same-input pairs remain.** A pair marked `same_input=1` must refer to the same
  output and label on both sides.
- **Contrasts use conversations.** Three seed differences are averaged within each
  conversation. Bootstrap draws resample these conversation-level values.
- **Order and seed are fixed.** The calculation retains first-seen conversation
  order and restarts seed `20261029` for each of the 24 contrasts, with 20,000 draws.
- **Percentage points are not percent change.** Fields ending in `_pp` multiply a
  difference in proportions by 100.

See `../DATA_DICTIONARY.md` for file-specific units and fields. Numerical replay
checks the calculations; the evaluation-process limits remain in the root README.

## Selector steps

`mbhc_core.py:matched_history` follows four steps:

1. Walk backward through history, saving each cumulative cost reached by the
   recent rule. Skip a record if it does not fit; continue to older records.
2. Score records by lexical overlap with the shared current state. Use dynamic
   programming to find the highest-scoring whole-record subset at each exact cost.
3. Choose the largest positive cost available to both selectors. Return a failure
   status if no such cost exists. Identical selected histories are allowed.
4. Put selected records back in chronological order and check their costs.

The caller supplies record costs keyed by `digest(line(record))`. Default JSON
spacing, Unicode handling, dictionary insertion order and prompt whitespace are
therefore preserved. `HISTORY_CAP` is a history-only allowance; complete request
budgets still need separate checks in the original pipeline.

On a score tie, the existing subset wins. Word overlap is summed in Python set
iteration order, as in the archived code. Tiny floating-point differences across
hash seeds can affect near ties. To compare old and new selectors, use the same
Python environment and `PYTHONHASHSEED`; the refactor does not introduce a new
tie-breaking policy. The synthetic tests do not measure native token lengths.

## Editing and checks

Use descriptive `snake_case` names, four-space indentation and one statement per
line. Keep comments beside the decision they explain: a denominator, ordering
constraint, alias or tie rule. Do not change data to make a check pass.

Run these commands from the repository root after downloading a release:

```console
python code/verify_manifest.py
python code/test_synthetic.py
python code/reproduce.py --out replay
```

For intervals, use Python 3.11 or later (required by NumPy 2.3.5), install the
pinned dependency and choose another output directory:

```console
python -m pip install -r requirements-bootstrap.txt
python code/reproduce.py --out replay_bootstrap --bootstrap
```

The output directory must be new. A failed reference check writes no result file.
An edited tracked file makes the manifest check fail until a maintainer reviews
the change and prepares a new manifest. The checker never silently accepts edits.
The manifest checks internal consistency; it is not a signature of authorship.
