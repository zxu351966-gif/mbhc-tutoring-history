"""Check listed release files and reject unexpected files outside generated folders."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST_NAME = "manifest_sha256.json"
IGNORED_DIRECTORIES = {".git", "__pycache__", ".venv", ".ruff_cache"}


def is_generated(relative_path):
    """Allow local replay outputs, caches and development environments."""
    return any(
        part in IGNORED_DIRECTORIES or part.startswith("replay") for part in relative_path.parts
    )


def verify_manifest(root=ROOT):
    """Return the checked file count or raise ValueError with a repairable message.

    This checks consistency with the supplied manifest, not who published it.
    The checker never rewrites the manifest or alters the checked files.
    """
    manifest = json.loads((root / MANIFEST_NAME).read_text(encoding="utf8"))
    mismatches = []
    for relative_path, expected_hash in manifest.items():
        path = root / relative_path
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected_hash:
            mismatches.append(relative_path)
    extras = [
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file()
        and path.relative_to(root).as_posix() not in manifest
        and path.name != MANIFEST_NAME
        and not is_generated(path.relative_to(root))
    ]
    if mismatches or extras:
        raise ValueError(f"Mismatch/missing: {mismatches!r}; unlisted: {extras!r}")
    return len(manifest)


def main():
    try:
        count = verify_manifest()
    except ValueError as error:
        raise SystemExit(str(error)) from error
    print(f"PASS: {count} manifest files; no unexpected release files")


if __name__ == "__main__":
    main()
