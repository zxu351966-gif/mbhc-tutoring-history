"""TEST_ONLY_SIMULATION: invented text and costs, not study observations or tokens.

These tests exercise selector behavior. They cannot validate source semantics,
native request budgets or the teachers' judgments.
"""

import json
import unittest
from unittest.mock import patch

import mbhc_core as selector


def record(index, text):
    return dict(context_id=f"C{index:04d}", source_kind="SYNTHETIC", role="teacher", text=text)


def choose(records, query, costs, cap):
    cost_table = {
        selector.digest(selector.line(row)): cost for row, cost in zip(records, costs)
    }
    # Restore the module default after each fixture so tests cannot affect one another.
    with patch.object(selector, "HISTORY_CAP", cap):
        return selector.matched_history(records, [record(99, query)], cost_table)


def ids(records):
    return [row["context_id"] for row in records]


class MatchedHistoryTests(unittest.TestCase):
    def test_distinct_histories_at_equal_cost(self):
        records = [record(1, "fraction"), record(2, "weather"), record(3, "fraction fraction")]
        recent, relevant, cost, status = choose(records, "fraction", [4, 4, 4], cap=8)
        self.assertEqual(ids(recent), ["C0002", "C0003"])
        self.assertEqual(ids(relevant), ["C0001", "C0003"])
        self.assertEqual((cost, status), (8, "MATCH_FOUND"))

    def test_no_lexical_match(self):
        self.assertEqual(
            choose([record(1, "weather")], "fraction", [4], cap=8),
            ([], [], 0, "NO_POSITIVE_WHOLE_ENTRY_MATCH"),
        )

    def test_identical_histories_are_retained(self):
        records = [record(1, "fraction")]
        recent, relevant, cost, status = choose(records, "fraction", [4], cap=8)
        self.assertEqual((recent, relevant, cost, status), (records, records, 4, "MATCH_FOUND"))

    def test_oversized_record_is_not_truncated(self):
        self.assertEqual(choose([record(1, "fraction")], "fraction", [9], cap=8)[2], 0)

    def test_recent_rule_skips_a_record_that_does_not_fit(self):
        records = [record(1, "fraction"), record(2, "fraction")]
        recent, relevant, cost, _ = choose(records, "fraction", [3, 9], cap=8)
        self.assertEqual((ids(recent), ids(relevant), cost), (["C0001"], ["C0001"], 3))

    def test_score_tie_keeps_the_earlier_relevant_record(self):
        records = [record(1, "fraction"), record(2, "fraction")]
        recent, relevant, cost, _ = choose(records, "fraction", [4, 4], cap=4)
        self.assertEqual((ids(recent), ids(relevant), cost), (["C0002"], ["C0001"], 4))

    def test_lexical_match_without_a_shared_cost_fails(self):
        records = [record(1, "fraction"), record(2, "weather")]
        self.assertEqual(
            choose(records, "fraction", [3, 4], cap=4),
            ([], [], 0, "NO_POSITIVE_WHOLE_ENTRY_MATCH"),
        )

    def test_empty_history_fails(self):
        self.assertEqual(choose([], "fraction", [], cap=8)[2], 0)

    def test_serialization_keeps_unicode_spacing_and_record_order(self):
        row = record(1, "分数")
        expected = '{"context_id": "C0001", "source_kind": "SYNTHETIC", "role": "teacher", "text": "分数"}\n'
        self.assertEqual(selector.line(row), expected)
        self.assertEqual(
            selector.body("test", [row], []),
            "case_id: test\nprior_history:\n" + expected + "shared_current_state:\n",
        )
        self.assertEqual(json.loads(selector.line(row)), row)

    def test_prompt_template_keeps_its_exact_whitespace(self):
        expected = (
            "<|im_start|>system\nsystem<|im_end|>\n"
            "<|im_start|>user\nquestion /no_think<|im_end|>\n"
            "<|im_start|>assistant\n<think>\n\n</think>\n\n"
        )
        self.assertEqual(selector.render("system", "question"), expected)


if __name__ == "__main__":
    unittest.main(verbosity=2)
