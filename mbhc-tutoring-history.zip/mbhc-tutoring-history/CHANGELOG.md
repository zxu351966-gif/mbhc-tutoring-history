# Changes

## 1.0.3

- Split the analysis script into named functions for each rating round and result.
- Expand the selector into four steps, with comments on costs, order and score ties.
- Add a code guide and ten named synthetic tests, including ties and serialization.
- Keep validation active under Python optimization and check unlisted release files
  before analysis. Write results only after all checks pass.
- Add formatting settings, ignore local outputs and preserve release bytes in Git.

Research data, prompts, expected values, licences and declarations are unchanged.
The original and revised scripts produce byte-identical results.json files for
point estimates and bootstrap intervals. Synthetic old/new selector comparisons
test implementation equivalence; they are not additional study evidence.

## 1.0.2

Consolidated assistance and responsibility statements in DECLARATIONS.md and
updated the README and data dictionary to distinguish teacher judgments from
post-review diagnostic coding. No changes to data, prompts, code, numerical
targets or licences.

## 1.0.1

Revised README and data dictionary for clarity. No changes to research data,
system prompts, analysis code, numerical targets or licences.

## 1.0.0

Initial release of the de-identified results, prompts and analysis code.
