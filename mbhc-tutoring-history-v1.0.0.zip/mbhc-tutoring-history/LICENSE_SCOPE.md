# Licence scope

Copyright (c) 2026 Tangfu Cen for material the author is entitled to license.

- code/: MIT, see LICENSES/MIT.txt.
- data/, expected/, prompts/, README.md, DATA_DICTIONARY.md, CITATION.cff,
  requirements-bootstrap.txt and release metadata: CC BY 4.0, see
  LICENSES/CC-BY-4.0.txt.

Preserve attribution and applicable notices. The release does not redistribute
the original TutorMoments or Eedi dialogues, questions, model answers or teacher
explanations. No upstream data licence or privacy permission is transferred.
The manifest documents file integrity and does not warrant source correctness.
