"""Check released files and report unlisted files outside generated directories."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'manifest_sha256.json').read_text(encoding='utf8'))
errors=[]
for rel,expected in manifest.items():
    p=root/rel
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:
        errors.append(rel)
extras=[p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.relative_to(root).as_posix() not in manifest and p.name!='manifest_sha256.json' and not any(x in {'.git','__pycache__','.venv'} or x.startswith('replay') for x in p.relative_to(root).parts)]
if errors or extras:
    raise SystemExit('Mismatch/missing: '+repr(errors)+'; unlisted: '+repr(extras))
print('PASS: '+str(len(manifest))+' manifest files; no unexpected release files')
