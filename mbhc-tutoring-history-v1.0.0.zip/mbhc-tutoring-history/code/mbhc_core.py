"""Verbatim AST-extracted executed selector; standard library only."""
import json,hashlib,collections,re,math
HISTORY_CAP=512

def digest(text):return hashlib.sha256(text.encode('utf-8')).hexdigest()

def line(entry):return json.dumps(entry,ensure_ascii=False)+'\n'

def body(cid,history,anchor):
    return 'case_id: '+cid+'\nprior_history:\n'+''.join(line(r) for r in history)+'shared_current_state:\n'+''.join(line(r) for r in anchor)

def render(system,user):
    return f'<|im_start|>system\n{system}<|im_end|>\n<|im_start|>user\n{user} /no_think<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n'

STOP=set('the and that this with what when have from your just like into here there then first would should could which why how for are you was were can not they she his her said but all now well yeah yes okay really going got about want know does doing mean more same get did one use let need think will how our out some also back going has been good very right because going make goes tell'.split())

WORD=re.compile(r'[a-z0-9]+')

def words(text):return {w for w in WORD.findall(text.lower()) if w not in STOP and (len(w)>2 or w.isdigit())}

def matched_history(past,anchor,cost):
    recent=[];states={};used=0
    for row in reversed(past):
        c=cost[digest(line(row))]
        if used+c<=HISTORY_CAP:
            recent.append(row);used+=c;states[used]=list(recent)
    query=words(' '.join(r['text'] for r in anchor));docs=[words(r['text']) for r in past];df=collections.Counter(w for doc in docs for w in doc)
    ranked=[]
    for i,r in enumerate(past):
        common=query & docs[i];score=sum(1+math.log((1+len(past))/(1+df[w])) for w in common)/math.sqrt(max(1,len(docs[i])))
        c=cost[digest(line(r))]
        if score>0 and 0<c<=HISTORY_CAP:ranked.append((r,c,score))
    # Exact subset-sum over native record-token weights; optimize lexicalscore only at a matched size.
    best=[None]*(HISTORY_CAP+1);best[0]=(0.0,())
    for i,(_,c,score) in enumerate(ranked):
        for target in range(HISTORY_CAP,c-1,-1):
            prev=best[target-c]
            if prev is None:continue
            total=prev[0]+score
            if best[target] is None or total>best[target][0]:best[target]=(total,prev[1]+(i,))
    common=[n for n in states if n>0 and best[n] is not None]
    if not common:return [],[],0,'NO_POSITIVE_WHOLE_ENTRY_MATCH'
    target=max(common);rel=[ranked[i][0] for i in best[target][1]];rec=states[target];order=lambda r:int(r['context_id'][1:])
    rec.sort(key=order);rel.sort(key=order)
    assert sum(cost[digest(line(r))] for r in rec)==target==sum(cost[digest(line(r))] for r in rel)
    assert len({r['context_id'] for r in rel})==len(rel)
    return rec,rel,target,'MATCH_FOUND'
