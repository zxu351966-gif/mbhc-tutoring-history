"""Synthetic selector tests; invented strings/costs, not study evidence or token counts."""
import mbhc_core as m
def row(i,text):return dict(context_id=f'C{i:04d}',source_kind='SYNTHETIC',role='teacher',text=text)
def run(rows,query,costs,cap):
 m.HISTORY_CAP=cap
 return m.matched_history(rows,[row(99,query)],{m.digest(m.line(r)):c for r,c in zip(rows,costs)})
rows=[row(1,'fraction'),row(2,'weather'),row(3,'fraction fraction')]
a,b,n,status=run(rows,'fraction',[4,4,4],8)
assert [r['context_id'] for r in a]==['C0002','C0003']
assert [r['context_id'] for r in b]==['C0001','C0003'] and n==8
assert run([row(1,'weather')],'fraction',[4],8)[2]==0
a,b,n,_=run([row(1,'fraction')],'fraction',[4],8);assert a==b and n==4
assert run([row(1,'fraction')],'fraction',[9],8)[2]==0
print('PASS: distinct, identical, no lexical match and oversized whole-record fixtures')
