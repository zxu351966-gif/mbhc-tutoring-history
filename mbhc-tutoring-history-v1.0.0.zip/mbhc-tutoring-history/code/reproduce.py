"""Reproduce retained-label numerical analyses. No network, model or private imports."""
from pathlib import Path
import argparse,collections,csv,json,math,statistics,hashlib
ROOT=Path(__file__).resolve().parents[1]
def read(name):return json.loads((ROOT/name).read_text('utf8'))
def rows(name):return list(csv.DictReader((ROOT/'data'/name).open(encoding='utf8',newline='')))
def counts(rr,field='NMA'):return {x:sum(r[field]==x for r in rr) for x in ['yes','no','uncertain']}
def agreement(rr,field='NMA'):
 by={w:{r['output']:r[field] for r in rr if r['teacher']==w} for w in ['A','B']};assert by['A'].keys()==by['B'].keys()
 n=len(by['A']);ct=collections.Counter((by['A'][k],by['B'][k]) for k in by['A']);a=collections.Counter(by['A'].values());b=collections.Counter(by['B'].values());same=sum(ct[x,x] for x in ['yes','no','uncertain']);pe=sum(a[x]*b[x] for x in ['yes','no','uncertain'])/n**2
 return dict(n=n,same=same,percent=100*same/n,kappa=(same/n-pe)/(1-pe),matrix=[dict(A=a,B=b,n=ct[a,b]) for a in ['yes','no','uncertain'] for b in ['yes','no','uncertain']])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--bootstrap',action='store_true',help='Requires numpy, recreates archived 20000-draw intervals');args=ap.parse_args();out=Path(args.out);out.mkdir()
 manifest=read('manifest_sha256.json')
 for path,h in manifest.items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==h,path
 actual=rows('tutor_actual264.csv');common=rows('tutor_common528.csv');ext=rows('eedi_original420.csv');slots=rows('eedi_original_slots456.csv');ep=rows('eedi_original_pairs144.csv');follow=rows('followup_judgments1512.csv');pairs=rows('followup_pairs720.csv')
 assert list(map(len,[actual,common,ext,slots,ep,follow,pairs]))==[264,528,420,456,144,1512,720]
 result={};result['table4_actual']=[dict(teacher=w,condition=c,**counts([r for r in actual if r['teacher']==w and r['condition']==c])) for w in ['A','B'] for c in ['recent','relevant']]
 assert [(r['yes'],r['no'],r['uncertain']) for r in result['table4_actual']]==[(35,9,0),(32,12,0),(33,8,3),(36,7,1)]
 result['table6_local']=[dict(teacher=w,**counts([r for r in actual if r['teacher']==w and r['condition']=='local'])) for w in ['A','B']]
 primary=[r for r in actual if r['condition'] in ['recent','relevant']]
 result['table5_agreement']={d:agreement(primary,d) for d in ['ACM','NMA','DA','EIS','NAMA','IAP']}
 assert [result['table5_agreement'][d]['same'] for d in ['ACM','NMA','DA','EIS','NAMA','IAP']]==[70,79,68,53,83,73]
 points=[]
 for unit in dict.fromkeys(r['unit'] for r in actual):
  point=dict(unit=unit)
  for w in ['A','B']:
   rr=[r for r in primary if r['teacher']==w and r['unit']==unit];assert len(rr)==8
   point[w]=25*(sum(r['NMA']=='yes' and r['condition']=='relevant' for r in rr)-sum(r['NMA']=='yes' and r['condition']=='recent' for r in rr))
  points.append(point)
 expected={r['unit']:r for r in rows('figure4_points.csv')}
 for p in points:
  for w in ['A','B']:assert p[w]==float(expected[p['unit']][w])
 result['figure4']=dict(points=points,leave_one_out=[dict(unit=p['unit'],**{w:statistics.mean(x[w] for x in points if x['unit']!=p['unit']) for w in ['A','B']}) for p in points])
 result['table2_common']=[]
 for w in ['A','B']:
  for seed in ['42','43','44']:
   cc={c:counts([r for r in common if r['teacher']==w and r['seed']==seed and r['condition']==c]) for c in ['recent','relevant']};result['table2_common'].append(dict(teacher=w,seed=int(seed),counts=cc,difference_pp=100*(cc['relevant']['yes']-cc['recent']['yes'])/44))
 result['common_agreement']={seed:agreement([r for r in common if r['seed']==seed]) for seed in ['42','43','44']}
 assert [r['counts']['recent']['yes'] for r in result['table2_common']]==[25,14,14,29,32,28]
 assert [r['counts']['relevant']['yes'] for r in result['table2_common']]==[29,18,18,31,29,31]
 eligible={r['unit'] for r in ep};result['table3_external']=[dict(teacher=w,seed=int(seed),condition=c,**counts([r for r in slots if r['teacher']==w and r['seed']==seed and r['condition']==c and r['unit'] in eligible])) for w in ['A','B'] for seed in ['42','43','44'] for c in ['recent','relevant','full_visible_prefix']]
 result['external_agreement']=agreement(ext);assert result['external_agreement']['same']==177
 result['external_distinct18']=[]
 for w in ['A','B']:
  rr=[r for r in ep if r['teacher']==w and r['same_input']=='0'];assert len(rr)==54
  result['external_distinct18'].append(dict(teacher=w,n=54,recent_yes=sum(r['recent']=='yes' for r in rr),relevant_yes=sum(r['relevant']=='yes' for r in rr)))
 # All five settings and both teachers, preserving archived order for bootstrap draws.
 effects={};conditions=[];seedcounts=[]
 for w in ['A','B']:
  for setting in dict.fromkeys(r['setting'] for r in pairs if r['teacher']==w):
   rr=[r for r in pairs if r['teacher']==w and r['setting']==setting];meta=rr[0];ids=list(dict.fromkeys(r['unit'] for r in rr));assert len(ids)==24 and len(rr)==72
   eff={u:sum(int(r['relevant']=='yes')-int(r['recent']=='yes') for r in rr if r['unit']==u)/3 for u in ids};effects[w,setting]=eff
   for r in rr:
    assert r['same_input'] in ['0','1']
    if r['same_input']=='1':assert r['recent_output']==r['relevant_output'] and r['recent']==r['relevant']
   model=meta['model'];cap=int(meta['cap']);rule=meta['rule']
   for cond in ['recent','relevant','full_visible_prefix_reference' if model=='Qwen3' else 'full_visible_prefix']:
    alias=f'{rule}_{cap}_{cond}' if model=='Qwen3' and cond in ['recent','relevant'] else cond
    selected=[r for r in follow if r['teacher']==w and r['model']==model and r['unit'] in ids and alias in json.loads(r['condition_aliases'])];ct=counts(selected);assert len(selected)==72
    conditions.append(dict(reviewer=w,model=model,cap=cap,rule=rule,cohort='common_qwen24' if model=='Qwen3' else 'model_primary24',condition=cond,conversations=24,repeated_condition_cells=72,unique_outputs=len({r['output'] for r in selected}),**ct,yes_percent=100*ct['yes']/72))
   for seed in ['42','43','44']:
    selected=[r for r in rr if r['seed']==seed];gain=sum(r['recent']!='yes' and r['relevant']=='yes' for r in selected);loss=sum(r['recent']=='yes' and r['relevant']!='yes' for r in selected)
    seedcounts.append(dict(reviewer=w,setting=setting,seed=int(seed),conversations=24,recent_yes=sum(r['recent']=='yes' for r in selected),relevant_yes=sum(r['relevant']=='yes' for r in selected),gain=gain,loss=loss,difference_pp=100*(gain-loss)/24,same_input_pairs=sum(r['same_input']=='1' for r in selected)))
 def close(a,b):
  if isinstance(a,dict):assert a.keys()==b.keys(),(a.keys(),b.keys());return all(close(a[k],b[k]) for k in a)
  if isinstance(a,list):assert len(a)==len(b);return all(close(x,y) for x,y in zip(a,b))
  if isinstance(a,(int,float)):assert math.isclose(a,b,abs_tol=1e-10),(a,b)
  else:assert a==b,(a,b)
  return True
 close(conditions,read('expected/followup_condition_counts.json'));close(seedcounts,read('expected/followup_seed_contrasts.json'))
 coverage=[]
 for e in read('expected/followup_coverage28.json'):
  selected=[r for r in follow if r['teacher']==e['reviewer'] and r['model']==e['model'] and e['condition'] in json.loads(r['condition_aliases'])]
  ct=counts(selected);assert len(selected)==84 and len({r['unit'] for r in selected})==28
  for k,v in ct.items():close(v,e[k])
  close(100*ct['yes']/84,e['yes_percent']);coverage.append(dict(reviewer=e['reviewer'],model=e['model'],condition=e['condition'],**ct))
 result['coverage28']=coverage
 contrasts=[]
 for e in read('expected/followup_contrasts.json'):
  w=e['reviewer'];name=e['contrast']
  if e['cohort']=='within_model24':vals=list(effects[w,f"{e['model']}_{e['rule']}_{e['cap']}"].values())
  elif name.startswith('Qwen3 ceiling minus exact'):
   cap=int(name.split('at')[1]);vals=[v-effects[w,f'Qwen3_exact_{cap}'][u] for u,v in effects[w,f'Qwen3_ceiling_{cap}'].items()]
  elif name.startswith('Qwen3 256 minus512'):
   rule=name.split()[-1];vals=[v-effects[w,f'Qwen3_{rule}_512'][u] for u,v in effects[w,f'Qwen3_{rule}_256'].items()]
  else:
   q=effects[w,'Qwen3_exact_512'];l=effects[w,'Llama3.1_exact_512'];ids=[u for u in q if u in l];assert len(ids)==22
   vals=[l[u]-q[u] if name.startswith('Llama minus') else (l[u] if name.startswith('Llama3.1') else q[u]) for u in ids]
  computed=dict(conversations=len(vals),difference_pp=100*statistics.mean(vals),conversation_min_pp=100*min(vals),conversation_max_pp=100*max(vals),positive_conversations=sum(v>0 for v in vals),zero_conversations=sum(v==0 for v in vals),negative_conversations=sum(v<0 for v in vals))
  for k,v in computed.items():close(v,e[k])
  if args.bootstrap:
   import numpy as np
   arr=np.asarray(vals);rng=np.random.default_rng(20261029);boots=arr[rng.integers(0,len(arr),size=(20000,len(arr)))].mean(axis=1);lo,hi=np.quantile(boots,[.025,.975]);computed.update(bootstrap95_lower_pp=100*float(lo),bootstrap95_upper_pp=100*float(hi))
   for k in ['bootstrap95_lower_pp','bootstrap95_upper_pp']:close(computed[k],e[k])
  contrasts.append(dict(teacher=w,contrast=name,**computed))
 result['followup_contrasts']=contrasts;result['followup_conditions']=conditions;result['followup_seeds']=seedcounts;result['followup_agreement']=agreement(follow)
 assert result['followup_agreement']['same']==532;close(result['followup_agreement']['kappa'],read('expected/followup_agreement.json')['kappa'])
 for short in ['attribution88','eis35']:
  ct=collections.Counter(c for r in rows('diagnostic_'+short+'.csv') for c in json.loads(r['code_ids']));result['diagnostic_'+short]=dict(ct)
 expected=read('expected/diagnostic_counts.json');close(result['diagnostic_attribution88'],expected['attribution_counts']);close(result['diagnostic_eis35'],expected['eis_reason_codes'])
 result['scope']='Numerical replay of retained judgments and fixed codes, not independent human validation or regeneration';result['bootstrap_recomputed']=args.bootstrap
 (out/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');print('PASS: Tables 2-7, Figure 4, external subset, all follow-up point contrasts, agreement and diagnostic counts'+('; bootstrap intervals' if args.bootstrap else ''))
if __name__=='__main__':main()
