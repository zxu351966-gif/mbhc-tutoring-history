# Data dictionary

All CSV files use UTF-8, a header row and comma separation. Quoted JSON arrays
in condition_aliases/code_ids are parsed with json.loads. No empty labels are
imputed. Teacher is A/B as in the paper. NMA and all six dimension columns use
yes/no/uncertain. A yes indicator is one, all other labels contribute zero only
to endorsement summaries; uncertain stays a separate reported category.

unit: random-order release code. S denotes a TutorMoments student and C an Eedi
conversation; C does not imply a unique student. output is a release code for
one archived generated output. The same code across conditions indicates an
alias, not an additional generation. round separates repeated evaluations.
seed is the original generation seed 42/43/44. prompt is the frozen system
prompt name. condition is recent/relevant/local/full_visible_prefix. Follow-up
aliases additionally encode exact/ceiling and history ceiling 256/512. model
identifies Qwen3 or Llama3.1. cap is the history ceiling, not context length.
same_input is 1 when recent/relevant refer to one shared output, otherwise 0.
setting combines model, budget rule and cap. Numeric differences are relevant
minus recent in percentage points, with equal weighting of units.

tutor_actual264.csv: 132 outputs x two teachers, six dimensions, adopted original
actual-input round. tutor_common528.csv: 88 outputs x three seeds x two teachers,
NMA only, with generation-seed and rating-round differences preserved.
eedi_original420.csv: 210 actual outputs x two teachers, original external round.
eedi_original_slots456.csv: 228 aliased condition slots x two teachers.
eedi_original_pairs144.csv: 24 conversations x three seeds x two teachers.
followup_judgments1512.csv: 756 actual outputs x two teachers, follow-up round.
followup_pairs720.csv: five settings x24 conversations x3 seeds x2 teachers.
figure4_points.csv: 11 student-level original actual-input contrasts for A/B.
queue_counts.json: all30 original external dispositions, including failures.
diagnostic_*: fixed AI-assisted categorical codes, row order alone carries no
published source locator. Categories can overlap. No original excerpts included.

ACM=action category match; NMA=next move appropriateness; DA=decision
appropriateness; EIS=evidence support; NAMA=next action mathematical accuracy;
IAP=independent attempt preserved. These are study judgments, not a validated
composite teaching-quality scale. See manuscript Table1 for definitions.

expected/: archived numerical targets used for replay checks. They are not newly
estimated results. code/reproduce.py recomputes estimates from data/ before
comparing with targets. Bootstrap uses20,000 draws and RNG seed20261029.
