# MBHC tutoring history comparison materials

Release version: 1.0.0. No DOI has been assigned.

This package contains pseudonymized retained-judgment tables, numerical results,
four exact system prompts, and portable analysis code. Codes S/C/O/T are new
package identifiers, not original source identifiers. Teacher A/B retain their
manuscript meaning. Remapping and omission of free text reduce disclosure risk,
but do not establish irreversible anonymity or permission to distribute.

## Run

Python 3.10 or later, standard library for point estimates:

    python code/test_synthetic.py
    python code/reproduce.py --out replay

To also reproduce the archived exploratory percentile intervals, use the
recorded NumPy version in requirements-bootstrap.txt:

    python code/reproduce.py --out replay_bootstrap --bootstrap

Output directories must not already exist. The scripts make no network requests,
call no models or tokenizers, and do not access the original project. Run `python code/verify_manifest.py` to verify the file manifest. Two local processes were used for replay validation,
not two independent research teams.

## Coverage

The retained-label replay covers Tables 2-7, all Figure 4 student/omission points,
the original Eedi 18-distinct-input subset, all 24 follow-up contrasts, and
attribution/EIS code counts. It preserves uncertainty labels, negative and zero
effects, each teacher, all seeds, and aliases for identical requests. Repeated
cells are not independent participants. Bootstrap intervals assume independent
conversations despite missing student identities and are exploratory.

The diagnostic code tables contain fixed AI-assisted codes, not new teacher
judgments. The per-action table alone does not reconstruct seed transitions
because its private source mapping is omitted. Figures 1/2 are conceptual,
Figure 3 has disposition counts, Figure 5 is qualitative and is not included as
redistributable source text. Table 1 is definitions, not estimated results.

The selector core is copied from the archived portable implementation. Its
synthetic tests use invented strings and costs, not research observations or
native token counts. This package cannot regenerate model
outputs or verify cutpoints/support semantics without the excluded source text.

## Evaluation provenance

Original actual-input, later common-reference and follow-up rounds remain
separate. Prior exposure, version changes, and author-reported transcription
from teacher handwriting remain methodological limitations. Reproducing numbers
does not verify authorship, independence, transcription accuracy or pedagogical
validity. Original labels have not been changed for release.

## Omitted material and release scope

Raw dialogue, question text, model answers, teacher reasons, handwriting,
names of teachers or learners, original source identifiers, personal timestamps,
filesystem paths and the private identifier mapping are excluded. Original
datasets remain subject to their providers' terms. The author has confirmed
sharing of this de-identified numerical package. That confirmation is not an
institutional ethics review or waiver, neither of which was obtained.

## Citation and licences

Creator: Tangfu Cen. Cite the exact Git commit used, with the repository title
and URL below. CITATION.cff provides machine-readable citation metadata.

https://github.com/zxu351966-gif/mbhc-tutoring-history

Code in code/ is licensed under MIT. Data, expected targets, prompts and authored
documentation are licensed under CC BY 4.0. See LICENSE_SCOPE.md and LICENSES/.
These licences do not grant rights over excluded third-party materials and do
not imply that pseudonymized records are irreversibly anonymous.
