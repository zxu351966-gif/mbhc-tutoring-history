# Changes

## 1.0.1

Revised README and data dictionary for clarity. No changes to research data,
system prompts, analysis code, numerical targets or licences.

## 1.0.0

Initial release of the de-identified results, prompts and analysis code.
