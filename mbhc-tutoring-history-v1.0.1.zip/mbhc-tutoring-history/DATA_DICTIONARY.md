# Data dictionary

CSV files use UTF-8, a header row and comma-separated fields. Parse the quoted
JSON arrays in `condition_aliases` and `code_ids` with `json.loads`.

## Fields

| Field | Meaning |
| --- | --- |
| teacher | A or B, as reported in the manuscript |
| unit | Randomly ordered release identifier: S for a TutorMoments student; C for an Eedi conversation. A conversation does not identify a unique student. |
| output | Identifier for one generated output. A repeated identifier across conditions denotes an alias. |
| round | Evaluation round |
| seed | Generation seed: 42, 43 or 44 |
| prompt | Frozen system-prompt name |
| condition | recent, relevant, local or full_visible_prefix |
| condition_aliases | Conditions linked to a shared output; follow-up aliases also identify the exact/ceiling rule and 256/512 history ceiling |
| model | Qwen3 or Llama3.1 |
| cap | History ceiling in tokens, distinct from the model context length |
| same_input | 1 when recent and relevant refer to one shared output; otherwise 0 |
| setting | Model, budget rule and history ceiling |
| code_ids | Diagnostic categories; categories may overlap |

The six rating dimensions use yes, no and uncertain. Endorsement summaries code
yes as one and other labels as zero, while reporting uncertain separately.
No missing label is imputed. Contrasts subtract recent from relevant and are
expressed in percentage points, with equal weighting of units.

## Data files

| File | Observations |
| --- | --- |
| tutor_actual264.csv | 132 outputs rated by two teachers on six dimensions in the adopted original actual-input round |
| tutor_common528.csv | 88 outputs across three seeds and two teachers; NMA only, retaining the evaluation round |
| eedi_original420.csv | 210 unique outputs rated by two teachers in the original external round |
| eedi_original_slots456.csv | 228 aliased condition slots, each rated by two teachers |
| eedi_original_pairs144.csv | 24 conversations, three seeds and two teachers |
| followup_judgments1512.csv | 756 unique outputs rated by two teachers in the follow-up round |
| followup_pairs720.csv | Five settings, 24 conversations, three seeds and two teachers |
| figure4_points.csv | Original actual-input contrasts for 11 students, for teachers A and B |
| queue_counts.json | Dispositions of all 30 external conversations, including failures |
| diagnostic_*.csv | Fixed AI-assisted categorical codes, without independent teacher validation or original excerpts; row order supplies no source locator |

## Rating dimensions

| Abbreviation | Full name |
| --- | --- |
| ACM | Action category match |
| NMA | Next move appropriateness |
| DA | Decision appropriateness |
| EIS | Evidence support |
| NAMA | Next action mathematical accuracy |
| IAP | Independent attempt preserved |

These are study judgments, not a validated composite teaching-quality scale.
Manuscript Table 1 provides the definitions.

## Reference values

The `expected/` files contain archived numerical targets. `code/reproduce.py`
recalculates estimates from `data/` before comparing them with those targets.
The bootstrap uses 20,000 draws and random-number seed 20261029.
